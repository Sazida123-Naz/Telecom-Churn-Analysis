#!/usr/bin/env python
# coding: utf-8

# # Importing Necessary Libraries

# import numpy as np
# import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn as sns
# 

# # Importing Datasets

# In[2]:


churn_data=pd.read_csv(r"C:\Users\Swastika jana\Downloads\churn_data.csv")


# In[3]:


churn_data


# In[4]:


customer_data=pd.read_csv(r"C:\Users\Swastika jana\Downloads\customer_data.csv")


# In[5]:


customer_data


# In[6]:


internet_data=pd.read_csv(r"C:\Users\Swastika jana\Downloads\internet_data.csv")


# In[7]:


internet_data


# # Merging these 3 Datasets

# In[8]:


merge_df=churn_data.merge(customer_data,on="customerID",how="inner").merge(internet_data,on="customerID",how="inner")


# In[9]:


merge_df


# In[10]:


main_df=merge_df.copy()


# In[11]:


main_df


# In[12]:


main_df.info()


# In[13]:


main_df.describe()


# In[14]:


main_df.shape


# # Checking all columns datatypes

# In[15]:


main_df.dtypes


# In[16]:


main_df.isnull().sum()


# # Drop the unnecessary columns Day,year,month,DOB

# In[17]:


main_df.drop(columns=["Day","year","month","DOB"],inplace=True)


# In[18]:


main_df


# In[19]:


main_df.isnull().sum()


# In[20]:


main_df["TotalCharges"]=main_df["TotalCharges"].replace(" ","0")


# In[21]:


main_df.isnull().sum()


# In[22]:


main_df[np.isnan(main_df["TotalCharges"])]


# In[23]:


main_df.fillna(main_df["TotalCharges"].mean())


# In[24]:


main_df[main_df["tenure"]==0]


# In[25]:


main_df[main_df["tenure"]==0].index


# In[26]:


main_df.drop(labels=main_df[main_df["tenure"]==0].index,axis=0,inplace=True)


# In[27]:


main_df[main_df["tenure"]==0].index


# In[28]:


main_df.isnull().sum()


# In[29]:


main_df.describe()


# In[30]:


main_df[main_df["customerID"].duplicated()]


# In[31]:


def conv(value):
    if value==1:
        return "Yes"
    else:
        return "No"

main_df["SeniorCitizen"]=main_df["SeniorCitizen"].apply(conv)


# In[32]:


main_df.head()


# In[33]:


main_df["SeniorCitizen"].value_counts()


# In[34]:


plt.figure(figsize=(4,5))
ax=sns.countplot(x=main_df["Churn"],data=main_df)
ax.bar_label(ax.containers[0])
plt.title("Count of customers by churn")
plt.show()


# In[35]:


plt.figure(figsize=(4,5))
gb=main_df.groupby("Churn").agg({"Churn":"count"})
gb
plt.pie(gb["Churn"],labels=gb.index,autopct="%1.2f%%")
plt.title("Percentage of Churned Customers",fontsize=10)
plt.show()


# # Note:- From the above Pie Chart we can conclude that 26.58% customers are churned out

# In[36]:


plt.figure(figsize=(4,5))
sns.countplot(x="gender",data=main_df,hue="Churn")
plt.title("Churn By Gender")


# In[42]:


plt.figure(figsize=(9,6))
sns.histplot(x="tenure",data=main_df,bins=70,hue="Churn")
plt.title("Churn Cout By number of Tenure")
plt.show()


# # Note:- People who have used our services for a long time have stayed and people who have used our services for 1 or 2 months have churned .

# In[39]:


plt.figure(figsize=(4,5))
ax=sns.countplot(x="Contract",data=main_df,hue="Churn")
ax.bar_label(ax.containers[0])
plt.title("Count of customers by Contract")
plt.show()


# # Note:-People who have month to month contract are likely to churn then from those who have 1 or 2 years of contract

# In[40]:


plt.figure(figsize=(6,4))
ax=sns.countplot(x="PaymentMethod",data=main_df,hue="Churn")
ax.bar_label(ax.containers[0])
ax.bar_label(ax.containers[1])

plt.title("Churned Customers by payment Method")
plt.xticks(rotation=45)
plt.show()


# # Note :- Customers is likely to churn when they are using Electronic check as payment method

# In[41]:


main_df.columns


# In[42]:


sns.boxplot(data=main_df,x="Churn",y="MonthlyCharges",hue="Churn",palette={"Yes":"#FF9999","No":"#99CCFF"})
plt.title("MonthlyCharges vs Churn")
plt.show()


# In[43]:


columns=["PhoneService","MultipleLines","InternetService","OnlineSecurity","OnlineBackup","DeviceProtection","TechSupport","StreamingTV","StreamingMovies"]
n_cols=3
n_rows=(len(columns)+ n_cols-1)//n_cols

fig,axes=plt.subplots(n_rows,n_cols,figsize=(15,n_rows*4))

axes=axes.flatten()
for i,col in enumerate(columns):
    sns.countplot(x=col,data=main_df,ax=axes[i],hue=main_df["Churn"])
    axes[i].set_title(f'Count plot of {col}')
    axes[i].set_xlabel(col)
    axes[i].set_ylabel("Count")
for j in range(i+1,len(axes)):
    fig.delaxes(axes[j])

plt.tight_layout()
plt.show()


# # Note:-  The Majority of customers who do not churn tend to have services like PhoneService,InternetService(Particularly DSL) and OnlineSecurity enabled.For Services like OnlineBackup,TechSupport,StreamingTV churn rate noticably higher when these services are not used or are unavailable.

# In[46]:


numerical_df = main_df.select_dtypes(include=['int64', 'float64'])

if main_df['Churn'].dtype == 'object':
    numerical_df['Churn'] = main_df['Churn'].map({'Yes': 1, 'No': 0})

# Calculate the correlation matrix
corr_matrix = numerical_df.corr()

plt.figure(figsize=(10, 7))
sns.heatmap(corr_matrix, annot=True, fmt=".2f", cmap='Blues')
plt.title("Correlation Matrix for Numerical Variables")
plt.tight_layout()
plt.show()


# In[ ]:





# In[ ]:




